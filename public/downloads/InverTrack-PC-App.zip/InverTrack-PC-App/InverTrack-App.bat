@echo off
setlocal
title InverTrack AI - Cartera de Inversiones
cd /d "%~dp0"
set "APP_FILE=%~dp0InverTrack.html"

where msedge >nul 2>nul
if %ERRORLEVEL% equ 0 (
    start "" msedge --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)

where chrome >nul 2>nul
if %ERRORLEVEL% equ 0 (
    start "" chrome --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)

if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app="file:///%APP_FILE:\=/%" --window-size=1300,850
    exit /b
)

start "" "%APP_FILE%"
