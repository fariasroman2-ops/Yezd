#!/usr/bin/env bash
DIR="$( cd "$( dirname "\$0" )" && pwd )"
HTML_FILE="\$DIR/InverTrack.html"
if command -v open >/dev/null 2>&1; then
    open "\$HTML_FILE"
elif command -v xdg-open >/dev/null 2>&1; then
    xdg-open "\$HTML_FILE"
fi
