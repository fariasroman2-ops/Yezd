Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "InverTrack-App.bat", 0, False
